/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["Fredoka", "sans-serif"],
        body: ["Poppins", "sans-serif"],
        tag: ["'Space Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
