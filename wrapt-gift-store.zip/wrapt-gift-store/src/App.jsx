import React, { useState, useMemo, useRef } from "react";
import Header from "./components/Header.jsx";
import Hero from "./components/Hero.jsx";
import CategoryShelf from "./components/CategoryShelf.jsx";
import ProductCard from "./components/ProductCard.jsx";
import ProductModal from "./components/ProductModal.jsx";
import CartDrawer from "./components/CartDrawer.jsx";
import Toast from "./components/Toast.jsx";
import Footer from "./components/Footer.jsx";
import { PRODUCTS, CATEGORIES } from "./data/products.js";

export default function App() {
  const [activeCat, setActiveCat] = useState(null);
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState({}); // id -> qty
  const [modalProduct, setModalProduct] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [toast, setToast] = useState({ show: false, message: "" });
  const toastTimer = useRef(null);
  const gridRef = useRef(null);

  const filtered = useMemo(() => {
    return PRODUCTS.filter((p) => {
      const matchesCat = !activeCat || p.cat === activeCat;
      const matchesQuery = p.name.toLowerCase().includes(query.trim().toLowerCase());
      return matchesCat && matchesQuery;
    });
  }, [activeCat, query]);

  const cartItems = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const p = PRODUCTS.find((pr) => pr.id === id);
          return p ? { ...p, qty } : null;
        })
        .filter(Boolean),
    [cart]
  );
  const cartCount = cartItems.reduce((n, i) => n + i.qty, 0);

  function showToast(message) {
    setToast({ show: true, message });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast((t) => ({ ...t, show: false })), 2200);
  }

  function addToCart(product, qty = 1) {
    setCart((c) => ({ ...c, [product.id]: (c[product.id] || 0) + qty }));
    showToast(`Added "${product.name}" to your basket`);
    setModalProduct(null);
  }

  function buyNow(product, qty = 1) {
    setCart((c) => ({ ...c, [product.id]: (c[product.id] || 0) + qty }));
    setModalProduct(null);
    setCartOpen(true);
  }

  function setQty(id, qty) {
    setCart((c) => ({ ...c, [id]: qty }));
  }

  function removeItem(id) {
    setCart((c) => {
      const next = { ...c };
      delete next[id];
      return next;
    });
  }

  function checkout() {
    setCartOpen(false);
    showToast("Order placed — thanks for shopping Wrapt");
    setCart({});
  }

  function scrollToShop(cat) {
    setActiveCat(cat);
    gridRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <div className="min-h-screen bg-emerald-950 font-body">
      <Header cartCount={cartCount} onCartOpen={() => setCartOpen(true)} query={query} setQuery={setQuery} />
      <Hero onShop={scrollToShop} />
      <CategoryShelf active={activeCat} onSelect={setActiveCat} />

      <main ref={gridRef} className="max-w-6xl mx-auto px-6 py-12">
        <div className="flex items-baseline justify-between mb-6">
          <h2 className="font-display text-emerald-50 text-2xl">
            {activeCat ? CATEGORIES.find((c) => c.id === activeCat)?.label : "All gifts"}
          </h2>
          <span className="font-tag text-emerald-400/70 text-xs uppercase tracking-widest">
            {filtered.length} item{filtered.length !== 1 ? "s" : ""}
          </span>
        </div>

        {filtered.length === 0 ? (
          <div className="py-24 text-center text-emerald-400/70">
            Nothing matches "{query}" in this category. Try clearing the search.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} onOpen={setModalProduct} onAdd={addToCart} />
            ))}
          </div>
        )}
      </main>

      <Footer />

      <ProductModal product={modalProduct} onClose={() => setModalProduct(null)} onAdd={addToCart} onBuyNow={buyNow} />

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onQty={setQty}
        onRemove={removeItem}
        onCheckout={checkout}
      />

      <Toast message={toast.message} show={toast.show} />
    </div>
  );
}
