import React from "react";
import { CheckIcon } from "./icons.jsx";

export default function Toast({ message, show }) {
  return (
    <div
      className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] bg-emerald-50 text-emerald-950 px-4 py-2.5 rounded-full text-sm flex items-center gap-2 shadow-xl transition-all duration-300 ${
        show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3 pointer-events-none"
      }`}
    >
      <CheckIcon className="w-4 h-4 text-rose-500" />
      {message}
    </div>
  );
}
