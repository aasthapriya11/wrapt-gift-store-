import React from "react";

export const CartIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <circle cx="9" cy="20" r="1.4" />
    <circle cx="18" cy="20" r="1.4" />
    <path
      d="M2.5 3h2.2l2 12.2a2 2 0 0 0 2 1.7h8.6a2 2 0 0 0 2-1.6l1.5-7.6H6.1"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const SearchIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <circle cx="11" cy="11" r="6.5" />
    <path d="M20 20l-4.3-4.3" strokeLinecap="round" />
  </svg>
);

export const CloseIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
    <path d="M5 5l14 14M19 5L5 19" strokeLinecap="round" />
  </svg>
);

export const PlusIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
    <path d="M12 5v14M5 12h14" strokeLinecap="round" />
  </svg>
);

export const MinusIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
    <path d="M5 12h14" strokeLinecap="round" />
  </svg>
);

export const StarIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
    <path d="M12 2.5l2.9 6.2 6.6.7-5 4.6 1.4 6.6L12 17l-5.9 3.6L7.5 14l-5-4.6 6.6-.7L12 2.5z" />
  </svg>
);

export const TrashIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <path
      d="M4 7h16M9 7V4.8A.8.8 0 0 1 9.8 4h4.4a.8.8 0 0 1 .8.8V7M6 7l.8 12.2a2 2 0 0 0 2 1.8h6.4a2 2 0 0 0 2-1.8L18 7"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const CheckIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
    <path d="M5 12.5l4.5 4.5L19 7" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const GiftIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
    <rect x="3.5" y="9" width="17" height="11" rx="1.2" />
    <path d="M3.5 9h17v3.2h-17z" fill="currentColor" stroke="none" opacity="0.25" />
    <path d="M12 9v11M3.5 9V20M20.5 9V20" strokeLinecap="round" />
    <path
      d="M12 9C9.5 9 8 7.3 8 5.7 8 4.5 8.9 3.6 10 3.6c1.6 0 2 1.9 2 5.4zM12 9c2.5 0 4-1.7 4-3.3 0-1.2-.9-2.1-2-2.1-1.6 0-2 1.9-2 5.4z"
      strokeLinejoin="round"
    />
  </svg>
);

export const TagIcon = (p) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
    <path
      d="M11.3 3.6l8 8a1.6 1.6 0 0 1 0 2.3l-6 6a1.6 1.6 0 0 1-2.3 0l-8-8a1.6 1.6 0 0 1-.5-1.1V4.6A1 1 0 0 1 3.5 3.6h6.7a1.6 1.6 0 0 1 1.1.5z"
      strokeLinejoin="round"
    />
    <circle cx="7.2" cy="7.7" r="1.1" fill="currentColor" stroke="none" />
  </svg>
);
