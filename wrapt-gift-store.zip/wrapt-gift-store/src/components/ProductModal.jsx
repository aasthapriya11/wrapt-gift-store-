import React, { useState, useEffect } from "react";
import { CloseIcon, CheckIcon, TagIcon } from "./icons.jsx";
import { Stars, Badge, QtyStepper } from "./ui.jsx";
import { imgFor, money } from "../utils/format.js";

export default function ProductModal({ product, onClose, onAdd, onBuyNow }) {
  const [qty, setQty] = useState(1);
  useEffect(() => setQty(1), [product]);
  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-6">
      <div className="absolute inset-0 bg-emerald-950/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-emerald-900 border border-emerald-800 w-full sm:max-w-3xl sm:rounded-2xl rounded-t-2xl max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-emerald-950/70 flex items-center justify-center text-emerald-200 hover:text-rose-300"
        >
          <CloseIcon className="w-4 h-4" />
        </button>
        <div className="grid sm:grid-cols-2 gap-0">
          <div className="aspect-square bg-emerald-800">
            <img src={imgFor(product.keyword, 800)} alt={product.name} className="w-full h-full object-cover" />
          </div>
          <div className="p-6 sm:p-8 flex flex-col gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                {product.badge && <Badge tone={product.badge === "Limited" ? "coral" : "gold"}>{product.badge}</Badge>}
                <span className="font-tag text-emerald-400/80 text-[11px] tracking-widest uppercase flex items-center gap-1">
                  <TagIcon className="w-3 h-3" /> Tag #{product.tagNo}
                </span>
              </div>
              <h2 className="font-display text-emerald-50 text-2xl sm:text-3xl leading-tight">{product.name}</h2>
              <div className="flex items-center gap-2 mt-2">
                <Stars rating={product.rating} />
                <span className="font-tag text-emerald-400/80 text-xs">
                  {product.rating} · {product.reviews} reviews
                </span>
              </div>
            </div>

            <p className="text-emerald-200/80 leading-relaxed">{product.blurb}</p>

            <div className="border-t border-b border-dashed border-emerald-700/70 py-4">
              <div className="font-tag text-[11px] uppercase tracking-widest text-emerald-400/80 mb-2">
                What&apos;s included
              </div>
              <ul className="space-y-1.5">
                {product.specs.map((s) => (
                  <li key={s} className="flex items-start gap-2 text-sm text-emerald-100">
                    <CheckIcon className="w-3.5 h-3.5 mt-0.5 text-rose-300 shrink-0" />
                    {s}
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-between">
              <span className="font-tag text-amber-300 text-2xl">{money(product.price)}</span>
              <QtyStepper qty={qty} onChange={setQty} />
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-1">
              <button
                onClick={() => onAdd(product, qty)}
                className="font-tag flex-1 py-3 rounded-full border border-rose-300 text-rose-300 uppercase text-xs tracking-wide hover:bg-rose-300/10 transition-colors"
              >
                Add to cart
              </button>
              <button
                onClick={() => onBuyNow(product, qty)}
                className="font-tag flex-1 py-3 rounded-full bg-rose-400 text-emerald-950 uppercase text-xs tracking-wide hover:bg-rose-300 transition-colors"
              >
                Buy now
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
