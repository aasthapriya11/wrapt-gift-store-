import React, { useState } from "react";
import { GiftIcon, SearchIcon, CartIcon } from "./icons.jsx";

export default function Header({ cartCount, onCartOpen, query, setQuery }) {
  const [searchOpen, setSearchOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 bg-emerald-950/90 backdrop-blur border-b border-emerald-800 h-16">
      <div className="max-w-6xl mx-auto px-6 h-full flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 shrink-0">
          <GiftIcon className="w-6 h-6 text-rose-300" />
          <span className="font-display text-emerald-50 text-lg tracking-tight">Wrapt</span>
        </div>

        <div className={`flex-1 max-w-sm ${searchOpen ? "flex" : "hidden sm:flex"} items-center`}>
          <div className="relative w-full">
            <SearchIcon className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search for a gift…"
              className="w-full bg-emerald-900 border border-emerald-800 rounded-full pl-9 pr-3 py-2 text-sm text-emerald-100 placeholder-emerald-500 focus:outline-none focus:border-rose-300"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setSearchOpen((s) => !s)}
            className="sm:hidden text-emerald-200 hover:text-rose-300 p-2"
            aria-label="Toggle search"
          >
            <SearchIcon className="w-5 h-5" />
          </button>
          <button
            onClick={onCartOpen}
            className="relative flex items-center gap-2 text-emerald-100 hover:text-rose-300 transition-colors p-2"
            aria-label="Open cart"
          >
            <CartIcon className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="font-tag absolute -top-1 -right-1 w-4.5 h-4.5 min-w-[18px] px-1 rounded-full bg-rose-400 text-emerald-950 text-[10px] leading-[18px] text-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
