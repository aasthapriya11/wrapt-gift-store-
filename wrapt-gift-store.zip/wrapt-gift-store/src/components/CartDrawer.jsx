import React from "react";
import { GiftIcon, CloseIcon, TrashIcon } from "./icons.jsx";
import { QtyStepper } from "./ui.jsx";
import { imgFor, money } from "../utils/format.js";

export default function CartDrawer({ open, onClose, items, onQty, onRemove, onCheckout }) {
  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  return (
    <>
      <div
        className={`fixed inset-0 bg-emerald-950/70 backdrop-blur-sm z-40 transition-opacity duration-300 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />
      <aside
        className={`fixed top-0 right-0 h-full w-full sm:w-[420px] bg-emerald-900 border-l border-emerald-800 z-50 flex flex-col transition-transform duration-300 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-5 border-b border-dashed border-emerald-700/70">
          <h2 className="font-display text-emerald-50 text-xl">Your gift basket</h2>
          <button onClick={onClose} className="text-emerald-300 hover:text-rose-300">
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4">
          {items.length === 0 && (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-3 py-16">
              <GiftIcon className="w-10 h-10 text-emerald-700" />
              <p className="text-emerald-400/80 text-sm max-w-[220px]">
                Your basket is empty. Find something worth wrapping.
              </p>
            </div>
          )}
          {items.map((item) => (
            <div key={item.id} className="flex gap-3 pb-4 border-b border-emerald-800/80 last:border-none">
              <img src={imgFor(item.keyword, 160)} alt={item.name} className="w-16 h-16 rounded-lg object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-emerald-50 text-sm leading-snug pr-2">{item.name}</h4>
                  <button onClick={() => onRemove(item.id)} className="text-emerald-600 hover:text-rose-400 shrink-0">
                    <TrashIcon className="w-4 h-4" />
                  </button>
                </div>
                <div className="font-tag text-emerald-400/70 text-[11px] mt-0.5">Tag #{item.tagNo}</div>
                <div className="flex items-center justify-between mt-2">
                  <QtyStepper qty={item.qty} onChange={(q) => onQty(item.id, q)} small />
                  <span className="font-tag text-amber-300 text-sm">{money(item.price * item.qty)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {items.length > 0 && (
          <div className="p-5 border-t border-dashed border-emerald-700/70 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-emerald-300">Subtotal</span>
              <span className="font-tag text-emerald-50">{money(subtotal)}</span>
            </div>
            <p className="text-emerald-500/80 text-xs">Gift wrap available at checkout. Taxes calculated next step.</p>
            <button
              onClick={onCheckout}
              className="font-tag w-full py-3 rounded-full bg-rose-400 text-emerald-950 uppercase text-xs tracking-wide hover:bg-rose-300 transition-colors"
            >
              Checkout · {money(subtotal)}
            </button>
          </div>
        )}
      </aside>
    </>
  );
}
