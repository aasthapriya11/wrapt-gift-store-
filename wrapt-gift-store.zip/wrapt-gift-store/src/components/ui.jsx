import React from "react";
import { StarIcon, MinusIcon, PlusIcon } from "./icons.jsx";

export function Stars({ rating }) {
  return (
    <div className="flex items-center gap-0.5 text-amber-400">
      {[0, 1, 2, 3, 4].map((i) => (
        <StarIcon key={i} className={`w-3.5 h-3.5 ${i < Math.round(rating) ? "opacity-100" : "opacity-25"}`} />
      ))}
    </div>
  );
}

export function Badge({ children, tone = "coral" }) {
  const tones = {
    coral: "bg-rose-400 text-emerald-950",
    gold: "bg-amber-300 text-emerald-950",
  };
  return (
    <span className={`font-tag inline-block px-2 py-0.5 text-[10px] tracking-widest uppercase rounded-sm ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function QtyStepper({ qty, onChange, small }) {
  return (
    <div className={`flex items-center border border-emerald-700 rounded-full ${small ? "h-8" : "h-10"}`}>
      <button
        onClick={() => onChange(Math.max(1, qty - 1))}
        className="px-2.5 h-full flex items-center justify-center text-emerald-200 hover:text-rose-300 transition-colors"
        aria-label="Decrease quantity"
      >
        <MinusIcon className="w-3.5 h-3.5" />
      </button>
      <span className="font-tag w-6 text-center text-sm text-emerald-50">{qty}</span>
      <button
        onClick={() => onChange(qty + 1)}
        className="px-2.5 h-full flex items-center justify-center text-emerald-200 hover:text-rose-300 transition-colors"
        aria-label="Increase quantity"
      >
        <PlusIcon className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
