import React from "react";
import { TagIcon } from "./icons.jsx";
import { Stars, Badge } from "./ui.jsx";
import { imgFor, money } from "../utils/format.js";

export default function ProductCard({ product, onOpen, onAdd }) {
  return (
    <div className="group relative flex flex-col bg-emerald-900 border border-emerald-800 rounded-2xl overflow-hidden hover:border-rose-300/60 transition-colors">
      <div className="absolute top-3 left-3 w-3 h-3 rounded-full bg-emerald-950 border border-emerald-700 z-10" />
      <button onClick={() => onOpen(product)} className="relative aspect-square overflow-hidden bg-emerald-800 text-left">
        <img
          src={imgFor(product.keyword)}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/60 via-transparent to-transparent" />
        {product.badge && (
          <div className="absolute top-3 right-3">
            <Badge tone={product.badge === "Limited" ? "coral" : "gold"}>{product.badge}</Badge>
          </div>
        )}
        <div className="font-tag absolute bottom-3 left-3 flex items-center gap-1 text-[10px] tracking-widest text-emerald-50/90 uppercase bg-emerald-950/60 px-2 py-1 rounded-full">
          <TagIcon className="w-3 h-3" /> Tag #{product.tagNo}
        </div>
      </button>

      <div className="flex flex-col flex-1 p-4 gap-2 border-t border-dashed border-emerald-700/70">
        <button onClick={() => onOpen(product)} className="text-left">
          <h3 className="font-display text-emerald-50 leading-snug text-[17px]">{product.name}</h3>
        </button>
        <div className="flex items-center gap-2">
          <Stars rating={product.rating} />
          <span className="font-tag text-emerald-400/80 text-xs">
            {product.rating} ({product.reviews})
          </span>
        </div>
        <p className="text-emerald-200/70 text-sm leading-relaxed line-clamp-2">{product.blurb}</p>

        <div className="mt-auto pt-3 flex items-center justify-between">
          <span className="font-tag text-amber-300 text-lg">{money(product.price)}</span>
          <button
            onClick={() => onAdd(product, 1)}
            className="font-tag text-xs uppercase tracking-wide px-3 py-2 rounded-full bg-rose-400 text-emerald-950 hover:bg-rose-300 active:scale-95 transition-all"
          >
            Add to cart
          </button>
        </div>
      </div>
    </div>
  );
}
