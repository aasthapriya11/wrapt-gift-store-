import React from "react";
import { CATEGORIES } from "../data/products.js";

export default function CategoryShelf({ active, onSelect }) {
  return (
    <section className="border-b border-emerald-800 bg-emerald-950 sticky top-[64px] z-30">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center gap-3 overflow-x-auto no-scrollbar">
        <button
          onClick={() => onSelect(null)}
          className={`font-tag shrink-0 px-4 py-2 rounded-full text-xs uppercase tracking-wide border transition-colors ${
            active === null
              ? "bg-rose-400 text-emerald-950 border-rose-400"
              : "border-emerald-700 text-emerald-200 hover:border-rose-300 hover:text-rose-300"
          }`}
        >
          All
        </button>
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => onSelect(c.id)}
            className={`font-tag shrink-0 px-4 py-2 rounded-full text-xs uppercase tracking-wide border transition-colors flex items-center gap-2 ${
              active === c.id
                ? "bg-rose-400 text-emerald-950 border-rose-400"
                : "border-emerald-700 text-emerald-200 hover:border-rose-300 hover:text-rose-300"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>
    </section>
  );
}
