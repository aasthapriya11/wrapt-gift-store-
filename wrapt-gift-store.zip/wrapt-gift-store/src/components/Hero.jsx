import React from "react";

export default function Hero({ onShop }) {
  return (
    <section className="relative overflow-hidden border-b border-emerald-800">
      <div
        className="absolute inset-0 opacity-[0.06] pointer-events-none"
        style={{
          backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
          backgroundSize: "22px 22px",
        }}
      />
      <div className="max-w-6xl mx-auto px-6 py-16 sm:py-24 grid sm:grid-cols-2 gap-12 items-center relative">
        <div>
          <div className="font-tag flex items-center gap-2 mb-5 text-rose-300 text-xs uppercase tracking-[0.2em]">
            <span className="w-6 h-px bg-rose-300" /> Every order arrives ready to give
          </div>
          <h1 className="font-display text-emerald-50 text-5xl sm:text-6xl leading-[1.02]">
            Something
            <br /> worth wrapping.
          </h1>
          <p className="text-emerald-200/80 mt-5 max-w-md leading-relaxed">
            Curated gifts for birthdays, new homes, thank-yous, and everything in between — each one tagged,
            boxed, and ready the moment it arrives.
          </p>
          <div className="flex flex-wrap gap-3 mt-8">
            <button
              onClick={() => onShop(null)}
              className="font-tag px-6 py-3 rounded-full bg-rose-400 text-emerald-950 text-sm uppercase tracking-wide hover:bg-rose-300 transition-colors"
            >
              Shop all gifts
            </button>
            <button
              onClick={() => onShop("birthday")}
              className="font-tag px-6 py-3 rounded-full border border-emerald-700 text-emerald-100 text-sm uppercase tracking-wide hover:border-rose-300 hover:text-rose-300 transition-colors"
            >
              Birthday picks
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center">
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 animate-sway">
            <div className="absolute inset-0 rounded-3xl bg-emerald-900 border border-emerald-700 shadow-2xl" />
            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 bg-rose-400 rounded-sm" />
            <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-8 bg-rose-400 rounded-sm" />
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center">
              <div className="w-12 h-9 bg-amber-300 rounded-full -rotate-12 -translate-x-3 shadow-md" />
              <div className="w-12 h-9 bg-amber-300 rounded-full rotate-12 translate-x-3 shadow-md" />
              <div className="absolute w-5 h-5 bg-amber-200 rounded-full border-2 border-emerald-900" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
