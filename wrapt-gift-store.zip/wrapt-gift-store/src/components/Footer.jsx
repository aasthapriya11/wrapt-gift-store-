import React from "react";
import { GiftIcon } from "./icons.jsx";
import { CATEGORIES } from "../data/products.js";

export default function Footer() {
  return (
    <footer className="border-t border-emerald-800 mt-20">
      <div className="max-w-6xl mx-auto px-6 py-12 grid sm:grid-cols-3 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <GiftIcon className="w-5 h-5 text-rose-300" />
            <span className="font-display text-emerald-50">Wrapt</span>
          </div>
          <p className="text-emerald-300/70 text-sm leading-relaxed max-w-xs">
            A small, curated shop for the gift-giving moments that matter — tagged, wrapped, and ready to hand
            over.
          </p>
        </div>
        <div>
          <div className="font-tag text-emerald-200 text-xs uppercase tracking-widest mb-3">Shop by occasion</div>
          <ul className="space-y-2 text-sm text-emerald-400/80">
            {CATEGORIES.map((c) => (
              <li key={c.id} className="hover:text-rose-300 transition-colors cursor-default">
                {c.label}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <div className="font-tag text-emerald-200 text-xs uppercase tracking-widest mb-3">Good to know</div>
          <ul className="space-y-2 text-sm text-emerald-400/80">
            <li>Shipping &amp; returns</li>
            <li>Free gift wrap over $50</li>
            <li>Add a handwritten note</li>
          </ul>
        </div>
      </div>
      <div className="font-tag border-t border-emerald-800 py-5 text-center text-emerald-500/70 text-xs">
        © 2026 Wrapt — demo store, all products fictional.
      </div>
    </footer>
  );
}
