export const imgFor = (keyword, size = 600) =>
  `https://loremflickr.com/${size}/${size}/${keyword}?lock=${keyword.length}`;

export const money = (n) => `$${n.toFixed(2)}`;
