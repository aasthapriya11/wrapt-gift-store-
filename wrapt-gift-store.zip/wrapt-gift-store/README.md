# Wrapt — Gift Store

A boutique gift-shop storefront built with React, Tailwind CSS, and plain JavaScript (no icon libraries or other packages).

## Project structure

```
wrapt-gift-store/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── src/
    ├── main.jsx              # React entry point
    ├── App.jsx                # top-level state (cart, filters, modals) + layout
    ├── index.css              # Tailwind + font imports + small custom keyframes
    ├── data/
    │   └── products.js        # category and product data
    ├── utils/
    │   └── format.js          # image URL + price formatting helpers
    └── components/
        ├── icons.jsx          # hand-drawn SVG icon set
        ├── ui.jsx             # Stars, Badge, QtyStepper
        ├── Header.jsx
        ├── Hero.jsx
        ├── CategoryShelf.jsx
        ├── ProductCard.jsx
        ├── ProductModal.jsx
        ├── CartDrawer.jsx
        ├── Toast.jsx
        └── Footer.jsx
```

## Run it locally

```bash
npm install
npm run dev
```

Then open the printed local URL (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```
